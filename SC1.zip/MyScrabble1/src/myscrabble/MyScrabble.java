/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package myscrabble;
import scrabble.gui.ScrabbleGame;

/**
 *
 * @author Adheesh
 */
public class MyScrabble {

    /**
     * @param args the command line arguments
     */
    private char letters[] = {
                      'A','A','A','A','A','A','A','A','A','A',
                      'A','A','B','B','C','C','C','C','D','D',
                      'D','E','E','E','E','E','E','E','E','E',
                      'E','E','E','E','F','G','G'
    }; 
    private int end = 36;
    
    public void get_letter(){
        //System.out.println(letters[0]);
        System.out.println(letters[end]);
        int random = (int)(Math.random()*end); 
        System.out.println(random + " " + letters[random]);
        char retChar = letters[random];
        letters[random] = letters[end];
        letters[end] = '!';
        System.out.println(letters[end]);
        System.out.println(retChar);
        System.out.println(random + " " + letters[random]);
        end--;
        System.out.println(letters[end]);
                
    }
    
    public static void main(String[] args) {
        // TODO code application logic here
        MyScrabble newgame =new MyScrabble();
        newgame.get_letter();        
    }
    
}
